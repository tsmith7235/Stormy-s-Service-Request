Locales = {
    ['en'] = {
        -- General
        ['tablet_title'] = "Stormy’s Service Request",
        ['tablet_subtitle'] = "Professional service coordination for your city.",
        ['open_tablet'] = "Open Service Request tablet",
        ['no_permission'] = "You do not have permission to do that.",
        ['not_available'] = "You must be Available to receive requests.",
        ['cooldown_active'] = "You must wait before submitting another request.",
        ['max_requests'] = "You already have an active request.",
        ['request_not_found'] = "Request not found.",
        ['invalid_status'] = "Invalid status transition.",
        ['too_far'] = "You are too far from the customer to mark arrived.",

        -- Player notifications
        ['request_submitted'] = "Service request %s has been submitted.",
        ['request_accepted'] = "Your service request %s has been accepted by %s.",
        ['request_arrived'] = "Your service provider has arrived.",
        ['request_completed'] = "Your service request %s has been completed.",
        ['request_cancelled'] = "Your service request %s has been cancelled.",
        ['request_declined'] = "Your service request was declined.",

        -- Employee notifications
        ['new_request'] = "New service request: %s",
        ['request_assigned'] = "You accepted request %s",
        ['request_already_taken'] = "This request has already been accepted.",

        -- Status labels
        ['status_pending'] = "Pending",
        ['status_accepted'] = "Accepted",
        ['status_enroute'] = "En Route",
        ['status_arrived'] = "Arrived",
        ['status_inprogress'] = "In Progress",
        ['status_completed'] = "Completed",
        ['status_declined'] = "Declined",
        ['status_cancelled'] = "Cancelled",
        ['status_expired'] = "Expired",
    }
}

function _L(key, ...)
    local str = Locales['en'][key] or key
    if ... then
        return string.format(str, ...)
    end
    return str
end