Bridge = Bridge or {}

Bridge.ESX = {}

local ESX = nil

CreateThread(function()
    if Config.Framework ~= 'esx' then return end
    while not ESX do
        local ok, obj = pcall(function()
            return exports['es_extended']:getSharedObject()
        end)
        if ok and obj then
            ESX = obj
        else
            TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
        end
        Wait(200)
    end
end)

function Bridge.ESX.GetPlayer(source)
    if not ESX then return nil end
    local xPlayer = ESX.GetPlayerFromId(source)
    if not xPlayer then return nil end
    return {
        source = source,
        identifier = xPlayer.identifier,
        name = xPlayer.getName(),
        job = {
            name = xPlayer.job.name,
            label = xPlayer.job.label,
            grade = xPlayer.job.grade
        },
        money = xPlayer.getMoney()
    }
end

function Bridge.ESX.GetIdentifier(source)
    local xPlayer = ESX and ESX.GetPlayerFromId(source)
    return xPlayer and xPlayer.identifier or nil
end

function Bridge.ESX.GetJob(source)
    local xPlayer = ESX and ESX.GetPlayerFromId(source)
    if not xPlayer then return { name = 'unemployed', label = 'Unemployed', grade = 0 } end
    return {
        name = xPlayer.job.name,
        label = xPlayer.job.label,
        grade = xPlayer.job.grade
    }
end

function Bridge.ESX.GetName(source)
    local xPlayer = ESX and ESX.GetPlayerFromId(source)
    return xPlayer and xPlayer.getName() or GetPlayerName(source)
end

function Bridge.ESX.IsAdmin(source)
    local xPlayer = ESX and ESX.GetPlayerFromId(source)
    if not xPlayer then return false end
    local group = xPlayer.getGroup()
    for _, g in ipairs(Config.AdminGroups) do
        if group == g then return true end
    end
    return false
end

function Bridge.ESX.Notify(source, message, type)
    TriggerClientEvent('esx:showNotification', source, message)
end

function Bridge.ESX.GetPlayers()
    if not ESX then return {} end
    local players = {}
    local xPlayers = ESX.GetPlayers()
    for _, id in ipairs(xPlayers) do
        players[#players+1] = id
    end
    return players
end