local activeBlips = {}

RegisterNetEvent('stormys_sr:client:createBlip', function(requestNumber, coords)
    if not Config.Blip.enabled then return end
    if activeBlips[requestNumber] then
        RemoveBlip(activeBlips[requestNumber])
    end

    local blip = AddBlipForCoord(coords.x, coords.y, coords.z)
    SetBlipSprite(blip, Config.Blip.sprite)
    SetBlipColour(blip, Config.Blip.color)
    SetBlipScale(blip, Config.Blip.scale)
    SetBlipAsShortRange(blip, Config.Blip.shortRange)
    BeginTextCommandSetBlipName('STRING')
    AddTextComponentString(Config.Blip.name .. ' ' .. requestNumber)
    EndTextCommandSetBlipName(blip)

    if Config.Blip.route then
        SetBlipRoute(blip, true)
    end

    activeBlips[requestNumber] = blip
end)

RegisterNetEvent('stormys_sr:client:removeBlip', function(requestNumber)
    if activeBlips[requestNumber] then
        RemoveBlip(activeBlips[requestNumber])
        activeBlips[requestNumber] = nil
    end
end)

AddEventHandler('onResourceStop', function(res)
    if res ~= GetCurrentResourceName() then return end
    for _, blip in pairs(activeBlips) do
        if DoesBlipExist(blip) then
            RemoveBlip(blip)
        end
    end
end)