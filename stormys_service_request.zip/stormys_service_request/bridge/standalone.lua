-- Standalone bridge (default)
-- Used when no framework is detected or Config.Framework = 'standalone'

Bridge = Bridge or {}

Bridge.Standalone = {}

function Bridge.Standalone.GetPlayer(source)
    return {
        source = source,
        identifier = GetPlayerIdentifierByType(source, 'license') or ('temp:' .. source),
        name = GetPlayerName(source) or 'Unknown',
        job = { name = 'unemployed', label = 'Unemployed', grade = 0 },
        money = 0
    }
end

function Bridge.Standalone.GetIdentifier(source)
    return GetPlayerIdentifierByType(source, 'license') or ('temp:' .. source)
end

function Bridge.Standalone.GetJob(source)
    return { name = 'unemployed', label = 'Unemployed', grade = 0 }
end

function Bridge.Standalone.GetName(source)
    return GetPlayerName(source) or 'Unknown'
end

function Bridge.Standalone.IsAdmin(source)
    -- Standalone has no groups – use ACE or hardcode for testing
    return IsPlayerAceAllowed(source, 'stormys.admin') or false
end

function Bridge.Standalone.Notify(source, message, type)
    TriggerClientEvent('stormys_sr:client:notify', source, message, type or 'info')
end

function Bridge.Standalone.GetPlayers()
    local players = {}
    for _, id in ipairs(GetPlayers()) do
        players[#players+1] = tonumber(id)
    end
    return players
end