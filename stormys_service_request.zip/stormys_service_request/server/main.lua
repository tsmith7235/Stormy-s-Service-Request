-- Stormy’s Service Request - Server Main

print('^2[Stormy’s Service Request]^0 Resource starting...')

-- ═══════════════════════════════════════════════════════════════
-- EVENTS
-- ═══════════════════════════════════════════════════════════════

RegisterNetEvent('stormys_sr:server:createRequest', function(data)
    local src = source
    if type(data) ~= 'table' then return end

    local success, result = Requests.Create(src, data)
    if success then
        TriggerClientEvent('stormys_sr:client:requestCreated', src, result)
        Permissions.Notify(src, _L('request_submitted', result), 'success')
    else
        Permissions.Notify(src, result or 'Failed to create request', 'error')
    end
end)

RegisterNetEvent('stormys_sr:server:acceptRequest', function(requestNumber)
    local src = source
    local success, err = Requests.Accept(src, requestNumber)
    if success then
        TriggerClientEvent('stormys_sr:client:requestAccepted', src, requestNumber)
    else
        Permissions.Notify(src, err or 'Failed to accept', 'error')
    end
end)

RegisterNetEvent('stormys_sr:server:updateStatus', function(requestNumber, newStatus, extra)
    local src = source
    local success, err = Requests.UpdateStatus(src, requestNumber, newStatus, extra or {})
    if success then
        TriggerClientEvent('stormys_sr:client:statusUpdated', src, requestNumber, newStatus)
    else
        Permissions.Notify(src, err or 'Failed to update status', 'error')
    end
end)

RegisterNetEvent('stormys_sr:server:cancelRequest', function(requestNumber)
    local src = source
    local success, err = Requests.CancelByPlayer(src, requestNumber)
    if success then
        TriggerClientEvent('stormys_sr:client:requestCancelled', src, requestNumber)
        Permissions.Notify(src, 'Request cancelled', 'inform')
    else
        Permissions.Notify(src, err or 'Failed to cancel', 'error')
    end
end)

RegisterNetEvent('stormys_sr:server:setAvailability', function(state)
    local src = source
    if not Permissions.IsServiceProvider(src) then return end
    local newState = Requests.SetAvailability(src, state)
    TriggerClientEvent('stormys_sr:client:availabilityChanged', src, newState)
end)

RegisterNetEvent('stormys_sr:server:getPlayerData', function()
    local src = source
    local player = Permissions.GetPlayer(src)
    local isProvider = Permissions.IsServiceProvider(src)
    local isAdmin = Permissions.IsAdmin(src)
    local myRequests = Requests.GetPlayerRequests(src)
    local openRequests = isProvider and Requests.GetOpenForEmployee(src) or {}
    local myActive = isProvider and Requests.GetMyActive(src) or {}
    local available = Requests.IsAvailable(src)

    TriggerClientEvent('stormys_sr:client:receivePlayerData', src, {
        player = player,
        isProvider = isProvider,
        isAdmin = isAdmin,
        myRequests = myRequests,
        openRequests = openRequests,
        myActive = myActive,
        available = available,
        categories = Config.Categories,
        priorities = Config.Priorities
    })
end)

RegisterNetEvent('stormys_sr:server:refreshData', function()
    local src = source
    local isProvider = Permissions.IsServiceProvider(src)
    local myRequests = Requests.GetPlayerRequests(src)
    local openRequests = isProvider and Requests.GetOpenForEmployee(src) or {}
    local myActive = isProvider and Requests.GetMyActive(src) or {}

    TriggerClientEvent('stormys_sr:client:refreshData', src, {
        myRequests = myRequests,
        openRequests = openRequests,
        myActive = myActive
    })
end)

-- Admin force actions
RegisterNetEvent('stormys_sr:server:adminAction', function(action, requestNumber, extra)
    local src = source
    if not Permissions.IsAdmin(src) then
        Permissions.Notify(src, _L('no_permission'), 'error')
        return
    end

    if action == 'cancel' then
        Database.CancelRequest(requestNumber)
        Permissions.Notify(src, 'Request force-cancelled', 'success')
    elseif action == 'complete' then
        Requests.UpdateStatus(src, requestNumber, 'completed', extra or {})
    end
end)

print('^2[Stormy’s Service Request]^0 Server loaded successfully.')
-- ═══════════════════════════════════════════════════════════════
-- PAYMENT EVENTS
-- ═══════════════════════════════════════════════════════════════

RegisterNetEvent('stormys_sr:server:createQuote', function(requestNumber, amount, description)
    local src = source
    local success, err = Requests.CreateQuote(src, requestNumber, amount, description)
    if success then
        TriggerClientEvent('stormys_sr:client:quoteSent', src, requestNumber)
        Permissions.Notify(src, 'Quote sent: $' .. tostring(amount), 'success')
    else
        Permissions.Notify(src, err or 'Failed to create quote', 'error')
    end
end)

RegisterNetEvent('stormys_sr:server:processPayment', function(requestNumber, method)
    local src = source
    local success, err = Requests.ProcessPayment(src, requestNumber, method)
    if not success then
        Permissions.Notify(src, err or 'Payment failed', 'error')
        TriggerClientEvent('stormys_sr:client:paymentFailed', src, err or 'Payment failed')
    end
end)
