Bridge = Bridge or {}

Bridge.Qbox = {}

local QBX = nil

CreateThread(function()
    if Config.Framework ~= 'qbox' then return end
    while not QBX do
        local ok, obj = pcall(function()
            return exports.qbx_core
        end)
        if ok and obj then
            QBX = obj
        end
        Wait(200)
    end
end)

function Bridge.Qbox.GetPlayer(source)
    if not QBX then return nil end
    local Player = QBX:GetPlayer(source)
    if not Player then return nil end
    return {
        source = source,
        identifier = Player.PlayerData.citizenid,
        name = Player.PlayerData.charinfo.firstname .. ' ' .. Player.PlayerData.charinfo.lastname,
        job = {
            name = Player.PlayerData.job.name,
            label = Player.PlayerData.job.label,
            grade = Player.PlayerData.job.grade.level
        },
        money = Player.PlayerData.money.cash
    }
end

function Bridge.Qbox.GetIdentifier(source)
    local Player = QBX and QBX:GetPlayer(source)
    return Player and Player.PlayerData.citizenid or nil
end

function Bridge.Qbox.GetJob(source)
    local Player = QBX and QBX:GetPlayer(source)
    if not Player then return { name = 'unemployed', label = 'Unemployed', grade = 0 } end
    return {
        name = Player.PlayerData.job.name,
        label = Player.PlayerData.job.label,
        grade = Player.PlayerData.job.grade.level
    }
end

function Bridge.Qbox.GetName(source)
    local Player = QBX and QBX:GetPlayer(source)
    if not Player then return GetPlayerName(source) end
    return Player.PlayerData.charinfo.firstname .. ' ' .. Player.PlayerData.charinfo.lastname
end

function Bridge.Qbox.IsAdmin(source)
    -- Qbox uses ace permissions primarily
    return IsPlayerAceAllowed(source, 'admin') or IsPlayerAceAllowed(source, 'command')
end

function Bridge.Qbox.Notify(source, message, type)
    TriggerClientEvent('ox_lib:notify', source, {
        title = 'Service Request',
        description = message,
        type = type or 'inform'
    })
end

function Bridge.Qbox.GetPlayers()
    local players = {}
    for _, id in ipairs(GetPlayers()) do
        players[#players+1] = tonumber(id)
    end
    return players
end