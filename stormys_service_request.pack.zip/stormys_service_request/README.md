# Stormy’s Service Request

**Free FiveM Resource** by **Stormys Lab Development**

A universal city-wide service request platform for FiveM RP (311-style).

Players request help from any configured service.  
Server owners decide which services exist and which jobs receive them.

---

## What This Is

This is **not** a mechanic tablet.  
This is **not** a police dispatch.  
This is **not** a medical-only system.

It is a **configurable service request network** that connects players with the jobs, departments, and businesses operating in the city.

Supported out of the box (and fully expandable):

- Vehicle / Mechanic / Tow
- Medical / EMS / Therapist
- Public Safety (non-emergency police)
- Real Estate / Property
- Business Services
- Taxi / Transportation
- City Services
- Personal / General Assistance
- Any custom jobs you add

---

## Features

- Modern 2027 glassmorphic tablet UI
- Fully configurable categories & request types
- Dynamic job routing (one universal request engine)
- Player + Employee views
- Employee dashboard only shows relevant requests
- Full request lifecycle with server validation
- Auto location + vehicle data capture
- Unique request numbers (`SR-####`)
- Availability toggle for employees
- GPS / waypoint support
- Anti-spam + cooldowns
- Framework bridges: ESX / QBCore / Qbox / Standalone
- oxmysql database
- Discord webhooks
- Clean, production-ready code

---

## Installation

1. Place `stormys_service_request` in your resources folder
2. Import `sql/install.sql` into your database
3. Add to `server.cfg`:
   ```
   ensure oxmysql
   ensure stormys_service_request
   ```
4. Open `config/config.lua` and set your framework:
   ```lua
   Config.Framework = 'qbcore' -- or 'esx', 'qbox', 'standalone'
   ```
5. Configure services & jobs in:
   - `config/categories.lua`  → categories & request types
   - `config/jobs.lua`        → which jobs receive which requests
6. Restart the server

---

## Commands

- `/servicerequest` (primary)
- `/request`
- `/helpme`
- `/service`

All commands are configurable.

---

## Dependencies

**Required**
- oxmysql

**Optional**
- ox_lib (better notifications)

---

## Architecture

One universal request engine powers every service.

```
Player → Category → Request Type → Job Routing → Employee Dashboard
```

Server owners can add completely new services by editing the two config files. No code changes required.

---

**Stormys Lab Development**  
*Get the help or service you need.*

---

## License / Terms of Use

You may download, install, and use this resource on your FiveM server.  
You may not sell, redistribute, re-upload, sublicense, or claim the resource or modified versions as your own.  

**Stormy’s Lab Development** retains ownership of the original work.

---

## Usable Item

The tablet can be used as an inventory item.

**Default item name:** `service_tablet`

### ox_inventory

Add this to your `ox_inventory/data/items.lua`:

```lua
['service_tablet'] = {
    label = 'Service Tablet',
    weight = 200,
    stack = false,
    close = true,
    description = 'Open Stormy’s Service Request tablet',
    client = {
        export = 'stormys_service_request.useServiceTablet'
    }
},
```

### QBCore / Qbox

Add the item to your `qb-core/shared/items.lua` (or items database):

```lua
service_tablet = {
    name = 'service_tablet',
    label = 'Service Tablet',
    weight = 200,
    type = 'item',
    image = 'tablet.png',
    unique = true,
    useable = true,
    shouldClose = true,
    description = 'Open Stormy’s Service Request tablet'
},
```

### ESX

Add the item to your items database / `items` table, then the resource will automatically register it as usable.

You can change the item name in `config/config.lua` → `Config.Item.name`
