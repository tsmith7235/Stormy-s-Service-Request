Bridge = Bridge or {}

Bridge.QBCore = {}

local QBCore = nil

CreateThread(function()
    if Config.Framework ~= 'qbcore' then return end
    while not QBCore do
        local ok, obj = pcall(function()
            return exports['qb-core']:GetCoreObject()
        end)
        if ok and obj then
            QBCore = obj
        end
        Wait(200)
    end
end)

function Bridge.QBCore.GetPlayer(source)
    if not QBCore then return nil end
    local Player = QBCore.Functions.GetPlayer(source)
    if not Player then return nil end
    return {
        source = source,
        identifier = Player.PlayerData.citizenid,
        name = Player.PlayerData.charinfo.firstname .. ' ' .. Player.PlayerData.charinfo.lastname,
        job = {
            name = Player.PlayerData.job.name,
            label = Player.PlayerData.job.label,
            grade = Player.PlayerData.job.grade.level
        },
        money = Player.PlayerData.money.cash
    }
end

function Bridge.QBCore.GetIdentifier(source)
    local Player = QBCore and QBCore.Functions.GetPlayer(source)
    return Player and Player.PlayerData.citizenid or nil
end

function Bridge.QBCore.GetJob(source)
    local Player = QBCore and QBCore.Functions.GetPlayer(source)
    if not Player then return { name = 'unemployed', label = 'Unemployed', grade = 0 } end
    return {
        name = Player.PlayerData.job.name,
        label = Player.PlayerData.job.label,
        grade = Player.PlayerData.job.grade.level
    }
end

function Bridge.QBCore.GetName(source)
    local Player = QBCore and QBCore.Functions.GetPlayer(source)
    if not Player then return GetPlayerName(source) end
    return Player.PlayerData.charinfo.firstname .. ' ' .. Player.PlayerData.charinfo.lastname
end

function Bridge.QBCore.IsAdmin(source)
    if not QBCore then return false end
    local Player = QBCore.Functions.GetPlayer(source)
    if not Player then return false end
    local perms = QBCore.Functions.GetPermission(source)
    for _, g in ipairs(Config.AdminGroups) do
        if perms[g] or (type(perms) == 'string' and perms == g) then
            return true
        end
    end
    return false
end

function Bridge.QBCore.Notify(source, message, type)
    TriggerClientEvent('QBCore:Notify', source, message, type or 'primary')
end

function Bridge.QBCore.GetPlayers()
    if not QBCore then return {} end
    local players = {}
    for _, id in pairs(QBCore.Functions.GetPlayers()) do
        players[#players+1] = id
    end
    return players
end