-- Stormy’s Service Request - Client Main

local isTabletOpen = false
local playerData = {}
local currentBlip = nil

-- ═══════════════════════════════════════════════════════════════
-- FRAMEWORK BRIDGE (client side helpers)
-- ═══════════════════════════════════════════════════════════════

local function Notify(msg, type)
    if Config.Notifications.useOxLib and GetResourceState('ox_lib') == 'started' then
        exports.ox_lib:notify({
            title = "Stormy’s Service Request",
            description = msg,
            type = type or 'inform',
            position = Config.Notifications.position
        })
    else
        BeginTextCommandThefeedPost('STRING')
        AddTextComponentSubstringPlayerName(msg)
        EndTextCommandThefeedPostTicker(false, true)
    end
end

RegisterNetEvent('stormys_sr:client:notify', function(msg, type)
    Notify(msg, type)
end)

-- ═══════════════════════════════════════════════════════════════
-- OPEN / CLOSE TABLET
-- ═══════════════════════════════════════════════════════════════

function OpenTablet()
    if isTabletOpen then return end
    isTabletOpen = true
    SetNuiFocus(true, true)
    TriggerServerEvent('stormys_sr:server:getPlayerData')
end

function CloseTablet()
    if not isTabletOpen then return end
    isTabletOpen = false
    SetNuiFocus(false, false)
    SendNUIMessage({ action = 'close' })
end

RegisterNUICallback('close', function(_, cb)
    CloseTablet()
    cb('ok')
end)

RegisterNUICallback('ready', function(_, cb)
    cb('ok')
end)

-- ═══════════════════════════════════════════════════════════════
-- COMMANDS
-- ═══════════════════════════════════════════════════════════════

if Config.Commands.enabled then
    RegisterCommand(Config.Commands.primary, function()
        OpenTablet()
    end, false)

    for _, alias in ipairs(Config.Commands.aliases) do
        RegisterCommand(alias, function()
            OpenTablet()
        end, false)
    end
end

if Config.Keybind.enabled then
    RegisterCommand('+stormys_sr_open', function()
        OpenTablet()
    end, false)
    RegisterKeyMapping('+stormys_sr_open', 'Open Service Request Tablet', 'keyboard', Config.Keybind.defaultKey)
end

-- ═══════════════════════════════════════════════════════════════
-- NUI CALLBACKS
-- ═══════════════════════════════════════════════════════════════

RegisterNUICallback('createRequest', function(data, cb)
    -- Auto capture location + vehicle
    local ped = PlayerPedId()
    local coords = GetEntityCoords(ped)
    local streetHash, crossingHash = GetStreetNameAtCoord(coords.x, coords.y, coords.z)
    local street = GetStreetNameFromHashKey(streetHash)
    local zone = GetLabelText(GetNameOfZone(coords.x, coords.y, coords.z))

    local vehicleData = {}
    local veh = GetVehiclePedIsIn(ped, false)
    if veh == 0 then
        veh = GetClosestVehicle(coords.x, coords.y, coords.z, 6.0, 0, 71)
    end

    if veh ~= 0 and DoesEntityExist(veh) then
        local model = GetEntityModel(veh)
        vehicleData.vehicle_model = model
        vehicleData.vehicle_name = GetDisplayNameFromVehicleModel(model)
        vehicleData.vehicle_plate = GetVehicleNumberPlateText(veh)
    end

    local payload = {
        category = data.category,
        type = data.type,
        description = data.description or '',
        priority = data.priority or 'normal',
        coords = { x = coords.x, y = coords.y, z = coords.z },
        street = street,
        zone = zone,
        postal = '', -- can be extended with postal resource
        vehicle_model = vehicleData.vehicle_model,
        vehicle_name = vehicleData.vehicle_name,
        vehicle_plate = vehicleData.vehicle_plate
    }

    TriggerServerEvent('stormys_sr:server:createRequest', payload)
    cb('ok')
end)

RegisterNUICallback('acceptRequest', function(data, cb)
    TriggerServerEvent('stormys_sr:server:acceptRequest', data.requestNumber)
    cb('ok')
end)

RegisterNUICallback('updateStatus', function(data, cb)
    TriggerServerEvent('stormys_sr:server:updateStatus', data.requestNumber, data.status, data.extra or {})
    cb('ok')
end)

RegisterNUICallback('cancelRequest', function(data, cb)
    TriggerServerEvent('stormys_sr:server:cancelRequest', data.requestNumber)
    cb('ok')
end)

RegisterNUICallback('setAvailability', function(data, cb)
    TriggerServerEvent('stormys_sr:server:setAvailability', data.state)
    cb('ok')
end)

RegisterNUICallback('setGPS', function(data, cb)
    if data.coords then
        SetNewWaypoint(data.coords.x, data.coords.y)
        Notify('GPS set to request location', 'success')
    end
    cb('ok')
end)

RegisterNUICallback('refresh', function(_, cb)
    TriggerServerEvent('stormys_sr:server:refreshData')
    cb('ok')
end)

-- ═══════════════════════════════════════════════════════════════
-- SERVER → CLIENT EVENTS
-- ═══════════════════════════════════════════════════════════════

RegisterNetEvent('stormys_sr:client:receivePlayerData', function(data)
    playerData = data
    SendNUIMessage({
        action = 'open',
        data = data,
        config = {
            brandName = Config.UI.brandName,
            brandSubtitle = Config.UI.brandSubtitle,
            accent = Config.UI.accentColor
        }
    })
end)

RegisterNetEvent('stormys_sr:client:refreshData', function(data)
    SendNUIMessage({
        action = 'refresh',
        data = data
    })
end)

RegisterNetEvent('stormys_sr:client:requestCreated', function(requestNumber)
    SendNUIMessage({ action = 'requestCreated', requestNumber = requestNumber })
end)

RegisterNetEvent('stormys_sr:client:newRequest', function(payload)
    SendNUIMessage({ action = 'newRequest', payload = payload })
    -- Optional sound for emergency
    if payload.priority == 'emergency' then
        PlaySoundFrontend(-1, 'CHECKPOINT_PERFECT', 'HUD_MINI_GAME_SOUNDSET', true)
    end
end)

RegisterNetEvent('stormys_sr:client:requestUpdated', function(requestNumber, status, name)
    SendNUIMessage({
        action = 'requestUpdated',
        requestNumber = requestNumber,
        status = status,
        name = name
    })
end)

RegisterNetEvent('stormys_sr:client:availabilityChanged', function(state)
    SendNUIMessage({ action = 'availabilityChanged', state = state })
end)

-- ═══════════════════════════════════════════════════════════════
-- CLEANUP
-- ═══════════════════════════════════════════════════════════════

AddEventHandler('onResourceStop', function(res)
    if res ~= GetCurrentResourceName() then return end
    if isTabletOpen then
        SetNuiFocus(false, false)
    end
    if currentBlip and DoesBlipExist(currentBlip) then
        RemoveBlip(currentBlip)
    end
end)

print('^2[Stormy’s Service Request]^0 Client loaded.')
-- ═══════════════════════════════════════════════════════════════
-- PAYMENT NUI + EVENTS
-- ═══════════════════════════════════════════════════════════════

RegisterNUICallback('createQuote', function(data, cb)
    TriggerServerEvent('stormys_sr:server:createQuote', data.requestNumber, data.amount, data.description or '')
    cb('ok')
end)

RegisterNUICallback('processPayment', function(data, cb)
    TriggerServerEvent('stormys_sr:server:processPayment', data.requestNumber, data.method)
    cb('ok')
end)

RegisterNetEvent('stormys_sr:client:quoteReceived', function(payload)
    SendNUIMessage({ action = 'quoteReceived', payload = payload })
end)

RegisterNetEvent('stormys_sr:client:quoteSent', function(requestNumber)
    SendNUIMessage({ action = 'quoteSent', requestNumber = requestNumber })
end)

RegisterNetEvent('stormys_sr:client:paymentSuccess', function(payload)
    SendNUIMessage({ action = 'paymentSuccess', payload = payload })
end)

RegisterNetEvent('stormys_sr:client:paymentReceived', function(payload)
    SendNUIMessage({ action = 'paymentReceived', payload = payload })
end)

RegisterNetEvent('stormys_sr:client:paymentFailed', function(msg)
    SendNUIMessage({ action = 'paymentFailed', message = msg })
end)
