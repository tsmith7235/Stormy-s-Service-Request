Permissions = {}

function Permissions.GetBridge()
    if Config.Framework == 'esx' then
        return Bridge.ESX
    elseif Config.Framework == 'qbcore' then
        return Bridge.QBCore
    elseif Config.Framework == 'qbox' then
        return Bridge.Qbox
    else
        return Bridge.Standalone
    end
end

function Permissions.GetPlayer(source)
    local bridge = Permissions.GetBridge()
    return bridge.GetPlayer(source)
end

function Permissions.GetJob(source)
    local bridge = Permissions.GetBridge()
    return bridge.GetJob(source)
end

function Permissions.GetName(source)
    local bridge = Permissions.GetBridge()
    return bridge.GetName(source)
end

function Permissions.GetIdentifier(source)
    local bridge = Permissions.GetBridge()
    return bridge.GetIdentifier(source)
end

function Permissions.IsAdmin(source)
    local bridge = Permissions.GetBridge()
    return bridge.IsAdmin(source)
end

function Permissions.IsServiceProvider(source)
    local job = Permissions.GetJob(source)
    if not job or not job.name then return false end
    for _, j in ipairs(Config.ServiceJobs) do
        if job.name == j then return true end
    end
    return false
end

function Permissions.CanReceiveCategory(source, category, typeId)
    local job = Permissions.GetJob(source)
    if not job or not job.name then return false end

    -- Check specific type first
    if typeId and Config.JobRouting[typeId] then
        for _, j in ipairs(Config.JobRouting[typeId]) do
            if job.name == j then return true end
        end
    end

    -- Fallback to category
    if Config.JobRouting[category] then
        for _, j in ipairs(Config.JobRouting[category]) do
            if job.name == j then return true end
        end
    end

    return false
end

function Permissions.Notify(source, message, type)
    local bridge = Permissions.GetBridge()
    bridge.Notify(source, message, type)
end

function Permissions.GetPlayers()
    local bridge = Permissions.GetBridge()
    return bridge.GetPlayers()
end