Config = {}

-- ═══════════════════════════════════════════════════════════════
-- FRAMEWORK
-- Options: 'esx', 'qbcore', 'qbox', 'standalone'
-- ═══════════════════════════════════════════════════════════════
Config.Framework = 'esx' -- Change this to match your server

-- ═══════════════════════════════════════════════════════════════
-- COMMANDS & KEYBINDS
-- ═══════════════════════════════════════════════════════════════
Config.Commands = {
    enabled = true,
    primary = 'servicerequest',   -- /servicerequest
    aliases = { 'request', 'helpme', 'service' }
}

Config.Keybind = {
    enabled = false,
    defaultKey = 'F7'             -- Only works if enabled
}

-- ═══════════════════════════════════════════════════════════════
-- GENERAL SETTINGS
-- ═══════════════════════════════════════════════════════════════
Config.Debug = false

Config.MaxActiveRequestsPerPlayer = 1
Config.CooldownAfterCancel = 5 * 60      -- seconds
Config.CooldownAfterComplete = 2 * 60    -- seconds
Config.RequestExpireTime = 60 * 60       -- 1 hour (seconds)

Config.ArrivalDistance = 25.0            -- meters required to mark Arrived
Config.RequireAvailability = true        -- Employees must be Available to receive requests

-- ═══════════════════════════════════════════════════════════════
-- PRIORITIES
-- ═══════════════════════════════════════════════════════════════
Config.Priorities = {
    { id = 'low',       label = 'Low',       color = '#94a3b8', weight = 1 },
    { id = 'normal',    label = 'Normal',    color = '#38bdf8', weight = 2 },
    { id = 'high',      label = 'High',      color = '#f59e0b', weight = 3 },
    { id = 'emergency', label = 'Emergency', color = '#ef4444', weight = 4 },
}

Config.DefaultPriority = 'normal'

-- ═══════════════════════════════════════════════════════════════
-- BLIPS / GPS
-- ═══════════════════════════════════════════════════════════════
Config.Blip = {
    enabled = true,
    sprite = 280,
    color = 3,
    scale = 0.9,
    name = 'Service Request',
    shortRange = false,
    route = true
}

-- ═══════════════════════════════════════════════════════════════
-- NOTIFICATIONS
-- ═══════════════════════════════════════════════════════════════
Config.Notifications = {
    useOxLib = true,          -- Prefer ox_lib if available
    position = 'top-right'
}

-- ═══════════════════════════════════════════════════════════════
-- DISCORD WEBHOOKS (leave empty to disable)
-- ═══════════════════════════════════════════════════════════════
Config.Webhooks = {
    requestCreated   = '',
    requestAccepted  = '',
    requestCompleted = '',
    requestCancelled = '',
    emergency        = '',
    adminAction      = ''
}

-- ═══════════════════════════════════════════════════════════════
-- ADMIN PERMISSIONS
-- ═══════════════════════════════════════════════════════════════
Config.AdminGroups = {
    'admin',
    'superadmin',
    'god',
    'owner'
}

-- ═══════════════════════════════════════════════════════════════
-- DATABASE
-- ═══════════════════════════════════════════════════════════════
Config.Database = {
    table = 'stormys_service_requests',
    historyRetentionDays = 30
}

-- ═══════════════════════════════════════════════════════════════
-- UI / TABLET
-- ═══════════════════════════════════════════════════════════════
Config.UI = {
    accentColor = '#2dd4bf',          -- Teal / cyan
    accentColorDark = '#0d9488',
    brandName = "Stormy’s Service Request",
    brandSubtitle = "Get the help or service you need."
}

-- ═══════════════════════════════════════════════════════════════
-- UNIVERSAL PAYMENT SYSTEM
-- ═══════════════════════════════════════════════════════════════
Config.Payments = {
    enabled = true,

    -- Where money goes after successful payment
    -- Options: 'provider' | 'society' | 'shared'
    destination = 'provider',

    -- If destination = 'society', use this society account name (framework dependent)
    societyAccount = 'society_mechanic',   -- example, change per service if needed

    -- If destination = 'shared', money goes to this identifier / account
    sharedAccount = '',

    -- Allow cash payments
    allowCash = true,

    -- Allow bank payments
    allowBank = true,

    -- Minimum quote amount
    minAmount = 1,

    -- Maximum quote amount (0 = unlimited)
    maxAmount = 0,
}