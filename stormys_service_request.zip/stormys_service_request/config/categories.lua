--[[
    STORMY’S SERVICE REQUEST - Categories & Services

    Universal city service platform.
    Server owners can freely add, remove, or rename categories and request types.
    Job routing is handled in config/jobs.lua
]]

Config.Categories = {
    {
        id = 'vehicle',
        label = 'Vehicle',
        icon = 'car',
        color = '#38bdf8',
        description = 'Mechanic, tow & roadside help',
        types = {
            { id = 'wont_start',        label = 'Vehicle Won’t Start' },
            { id = 'locked_out',        label = 'Locked Out' },
            { id = 'flat_tire',         label = 'Flat Tire' },
            { id = 'out_of_fuel',       label = 'Out of Fuel' },
            { id = 'vehicle_recovery',  label = 'Vehicle Recovery' },
            { id = 'roadside',          label = 'Roadside Assistance' },
            { id = 'accident',          label = 'Accident Assistance' },
            { id = 'other_vehicle',     label = 'Other Vehicle Issue' },
        }
    },
    {
        id = 'medical',
        label = 'Medical',
        icon = 'heart-pulse',
        color = '#f87171',
        description = 'Medical & emergency assistance',
        types = {
            { id = 'medical_assist',    label = 'Medical Assistance' },
            { id = 'ambulance',         label = 'Ambulance Request' },
            { id = 'non_emergency_med', label = 'Non-Emergency Medical' },
            { id = 'therapist',         label = 'Therapist Request' },
            { id = 'other_medical',     label = 'Other Medical' },
        }
    },
    {
        id = 'public_safety',
        label = 'Public Safety',
        icon = 'shield-halved',
        color = '#60a5fa',
        description = 'Police & civilian safety',
        types = {
            { id = 'non_emergency_police', label = 'Non-Emergency Police' },
            { id = 'welfare_check',        label = 'Welfare Check' },
            { id = 'suspicious',           label = 'Suspicious Activity' },
            { id = 'noise_complaint',      label = 'Noise Complaint' },
            { id = 'civilian_assist',      label = 'Civilian Assistance' },
            { id = 'other_safety',         label = 'Other Safety Issue' },
        }
    },
    {
        id = 'property',
        label = 'Property',
        icon = 'house',
        color = '#a78bfa',
        description = 'Real estate & property help',
        types = {
            { id = 'realtor_assist',    label = 'Realtor Assistance' },
            { id = 'property_viewing',  label = 'Property Viewing' },
            { id = 'property_inquiry',  label = 'Property Inquiry' },
            { id = 'lockout',           label = 'Lockout' },
            { id = 'maintenance',       label = 'Property Maintenance' },
            { id = 'other_property',    label = 'Other Property Issue' },
        }
    },
    {
        id = 'business',
        label = 'Business',
        icon = 'building',
        color = '#f59e0b',
        description = 'Business & customer services',
        types = {
            { id = 'customer_assist',   label = 'Customer Assistance' },
            { id = 'delivery',          label = 'Delivery Request' },
            { id = 'business_service',  label = 'Business Service' },
            { id = 'employee_assist',   label = 'Employee Assistance' },
            { id = 'other_business',    label = 'Other Business Issue' },
        }
    },
    {
        id = 'transportation',
        label = 'Transportation',
        icon = 'taxi',
        color = '#fbbf24',
        description = 'Taxi, rides & transport',
        types = {
            { id = 'taxi',              label = 'Taxi Request' },
            { id = 'ride',              label = 'Ride Request' },
            { id = 'transport_assist',  label = 'Transportation Assistance' },
            { id = 'other_transport',   label = 'Other Transport' },
        }
    },
    {
        id = 'city_services',
        label = 'City Services',
        icon = 'city',
        color = '#34d399',
        description = 'Public works & city help',
        types = {
            { id = 'road_hazard',       label = 'Road Hazard' },
            { id = 'abandoned_vehicle', label = 'Abandoned Vehicle' },
            { id = 'trash',             label = 'Trash / Recycling' },
            { id = 'public_maintenance',label = 'Public Maintenance' },
            { id = 'other_city',        label = 'Other City Service' },
        }
    },
    {
        id = 'personal',
        label = 'Personal',
        icon = 'user',
        color = '#f472b6',
        description = 'General personal assistance',
        types = {
            { id = 'lost_found',        label = 'Lost & Found' },
            { id = 'general',           label = 'General Assistance' },
            { id = 'other_personal',    label = 'Other' },
        }
    },
}