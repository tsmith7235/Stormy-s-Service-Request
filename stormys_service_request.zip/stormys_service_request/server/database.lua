Database = {}

local tableName = Config.Database.table

function Database.CreateTables()
    MySQL.query([[
        CREATE TABLE IF NOT EXISTS `]] .. tableName .. [[` (
            `id` INT NOT NULL AUTO_INCREMENT,
            `request_number` VARCHAR(20) NOT NULL,
            `citizenid` VARCHAR(64) NOT NULL,
            `player_name` VARCHAR(100) NOT NULL,
            `source_id` INT DEFAULT NULL,
            `category` VARCHAR(50) NOT NULL,
            `type` VARCHAR(50) NOT NULL,
            `description` TEXT,
            `priority` VARCHAR(20) DEFAULT 'normal',
            `status` VARCHAR(20) DEFAULT 'pending',
            `coords` LONGTEXT,
            `street` VARCHAR(128),
            `zone` VARCHAR(128),
            `postal` VARCHAR(20),
            `vehicle_model` VARCHAR(64),
            `vehicle_name` VARCHAR(64),
            `vehicle_plate` VARCHAR(20),
            `assigned_to` VARCHAR(64) DEFAULT NULL,
            `assigned_name` VARCHAR(100) DEFAULT NULL,
            `assigned_source` INT DEFAULT NULL,
            `quote_amount` INT DEFAULT NULL,
            `quote_description` TEXT,
            `quote_sent` TINYINT(1) DEFAULT 0,
            `payment_status` VARCHAR(20) DEFAULT 'none',
            `payment_method` VARCHAR(20) DEFAULT NULL,
            `paid_amount` INT DEFAULT NULL,
            `paid_at` TIMESTAMP NULL DEFAULT NULL,
            `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            `accepted_at` TIMESTAMP NULL DEFAULT NULL,
            `arrived_at` TIMESTAMP NULL DEFAULT NULL,
            `completed_at` TIMESTAMP NULL DEFAULT NULL,
            `resolution` TEXT,
            `notes` TEXT,
            PRIMARY KEY (`id`),
            UNIQUE KEY `request_number` (`request_number`),
            KEY `citizenid` (`citizenid`),
            KEY `status` (`status`),
            KEY `assigned_to` (`assigned_to`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    ]])

    -- Payment history table
    MySQL.query([[
        CREATE TABLE IF NOT EXISTS `stormys_service_payments` (
            `id` INT NOT NULL AUTO_INCREMENT,
            `request_number` VARCHAR(20) NOT NULL,
            `citizenid` VARCHAR(64) NOT NULL,
            `player_name` VARCHAR(100) NOT NULL,
            `provider_id` VARCHAR(64) DEFAULT NULL,
            `provider_name` VARCHAR(100) DEFAULT NULL,
            `amount` INT NOT NULL,
            `method` VARCHAR(20) NOT NULL,
            `destination` VARCHAR(50) DEFAULT 'provider',
            `status` VARCHAR(20) DEFAULT 'paid',
            `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`),
            KEY `request_number` (`request_number`),
            KEY `citizenid` (`citizenid`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    ]])
end

function Database.InsertRequest(data)
    local ok, result = pcall(function()
        return MySQL.insert.await([[
            INSERT INTO `]] .. tableName .. [[`
            (request_number, citizenid, player_name, source_id, category, type, description, priority, status, coords, street, zone, postal, vehicle_model, vehicle_name, vehicle_plate)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ]], {
            data.request_number,
            data.citizenid,
            data.player_name,
            data.source_id,
            data.category,
            data.type,
            data.description,
            data.priority,
            data.status or 'pending',
            json.encode(data.coords),
            data.street,
            data.zone,
            data.postal,
            data.vehicle_model,
            data.vehicle_name,
            data.vehicle_plate
        })
    end)
    if ok then return result else return nil end
end

function Database.UpdateStatus(requestNumber, status, extra)
    local query = 'UPDATE `' .. tableName .. '` SET status = ?'
    local params = { status }

    if status == 'accepted' then
        query = query .. ', assigned_to = ?, assigned_name = ?, assigned_source = ?, accepted_at = NOW()'
        params[#params+1] = extra.assigned_to
        params[#params+1] = extra.assigned_name
        params[#params+1] = extra.assigned_source
    elseif status == 'arrived' then
        query = query .. ', arrived_at = NOW()'
    elseif status == 'completed' then
        query = query .. ', completed_at = NOW(), resolution = ?, notes = ?'
        params[#params+1] = extra.resolution or ''
        params[#params+1] = extra.notes or ''
    end

    query = query .. ' WHERE request_number = ?'
    params[#params+1] = requestNumber

    return MySQL.update.await(query, params)
end

function Database.GetRequest(requestNumber)
    return MySQL.single.await('SELECT * FROM `' .. tableName .. '` WHERE request_number = ?', { requestNumber })
end

function Database.GetPlayerActiveRequests(citizenid)
    return MySQL.query.await('SELECT * FROM `' .. tableName .. '` WHERE citizenid = ? AND status IN ("pending","accepted","enroute","arrived","inprogress") ORDER BY created_at DESC', { citizenid })
end

function Database.GetOpenRequests()
    return MySQL.query.await('SELECT * FROM `' .. tableName .. '` WHERE status = "pending" ORDER BY FIELD(priority, "emergency","high","normal","low"), created_at ASC')
end

function Database.GetEmployeeActive(assignedTo)
    return MySQL.query.await('SELECT * FROM `' .. tableName .. '` WHERE assigned_to = ? AND status IN ("accepted","enroute","arrived","inprogress") ORDER BY created_at DESC', { assignedTo })
end

function Database.GetHistory(limit)
    limit = limit or 50
    return MySQL.query.await('SELECT * FROM `' .. tableName .. '` WHERE status IN ("completed","cancelled","declined","expired") ORDER BY completed_at DESC LIMIT ?', { limit })
end

function Database.CancelRequest(requestNumber)
    return MySQL.update.await('UPDATE `' .. tableName .. '` SET status = "cancelled" WHERE request_number = ?', { requestNumber })
end

function Database.SetQuote(requestNumber, amount, description)
    return MySQL.update.await(
        'UPDATE `' .. tableName .. '` SET quote_amount = ?, quote_description = ?, quote_sent = 1, payment_status = "pending" WHERE request_number = ?',
        { amount, description or '', requestNumber }
    )
end

function Database.MarkPaid(requestNumber, method, amount)
    return MySQL.update.await(
        'UPDATE `' .. tableName .. '` SET payment_status = "paid", payment_method = ?, paid_amount = ?, paid_at = NOW() WHERE request_number = ?',
        { method, amount, requestNumber }
    )
end

function Database.InsertPayment(data)
    return MySQL.insert.await([[
        INSERT INTO `stormys_service_payments`
        (request_number, citizenid, player_name, provider_id, provider_name, amount, method, destination, status)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    ]], {
        data.request_number,
        data.citizenid,
        data.player_name,
        data.provider_id,
        data.provider_name,
        data.amount,
        data.method,
        data.destination or 'provider',
        'paid'
    })
end

function Database.GetPaymentsByPlayer(citizenid)
    return MySQL.query.await(
        'SELECT * FROM `stormys_service_payments` WHERE citizenid = ? ORDER BY created_at DESC LIMIT 50',
        { citizenid }
    )
end

CreateThread(function()
    Wait(1000)
    Database.CreateTables()
end)