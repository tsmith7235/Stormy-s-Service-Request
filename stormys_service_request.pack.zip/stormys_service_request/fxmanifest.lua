fx_version 'cerulean'
game 'gta5'

name 'Stormy’s Service Request'
author 'Stormys Lab Development'
description 'Universal city-wide service request platform with modern glassmorphic tablet UI'
version '1.0.0'

lua54 'yes'

shared_scripts {
    'config/config.lua',
    'config/categories.lua',
    'config/jobs.lua',
    'locales/en.lua',
}

client_scripts {
    'bridge/esx.lua',
    'bridge/qbcore.lua',
    'bridge/qbox.lua',
    'bridge/standalone.lua',
    'client/main.lua',
    'client/ui.lua',
    'client/blips.lua',
}

server_scripts {
    '@oxmysql/lib/MySQL.lua',
    'bridge/esx.lua',
    'bridge/qbcore.lua',
    'bridge/qbox.lua',
    'bridge/standalone.lua',
    'server/database.lua',
    'server/permissions.lua',
    'server/requests.lua',
    'server/main.lua',
}

ui_page 'html/index.html'

files {
    'html/index.html',
    'html/css/*.css',
    'html/js/*.js',
    'html/assets/*',
}

-- Files that must remain editable (NOT locked by CFX escrow)
escrow_ignore {
    'config/*.lua',
    'locales/*.lua',
    'sql/*.sql',
    'README.md',
}

dependencies {
    'oxmysql',
}

optional_dependencies {
    'ox_lib',
    'ox_target',
}
dependency '/assetpacks'