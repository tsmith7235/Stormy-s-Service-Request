Requests = {}

local playerCooldowns = {} -- [citizenid] = timestamp
local employeeAvailability = {} -- [source] = true/false

-- Generate unique request number directly from the database (safe across restarts)
local function GenerateRequestNumber()
    local result = MySQL.single.await(
        'SELECT request_number FROM `stormys_service_requests` ORDER BY id DESC LIMIT 1'
    )

    local nextNum = 1001
    if result and result.request_number then
        local num = tonumber(string.match(result.request_number, '%d+'))
        if num then
            nextNum = num + 1
        end
    end

    return ('SR-%d'):format(nextNum)
end

-- Check if player is on cooldown
local function IsOnCooldown(citizenid)
    local now = os.time()
    if playerCooldowns[citizenid] and playerCooldowns[citizenid] > now then
        return true, playerCooldowns[citizenid] - now
    end
    return false, 0
end

function Requests.SetAvailability(source, state)
    employeeAvailability[source] = state and true or false
    return employeeAvailability[source]
end

function Requests.IsAvailable(source)
    if not Config.RequireAvailability then return true end
    return employeeAvailability[source] == true
end

function Requests.Create(source, data)
    local player = Permissions.GetPlayer(source)
    if not player then return false, 'Player not found' end

    local citizenid = player.identifier
    local onCooldown, remaining = IsOnCooldown(citizenid)
    if onCooldown then
        return false, _L('cooldown_active')
    end

    local active = Database.GetPlayerActiveRequests(citizenid)
    if active and #active >= Config.MaxActiveRequestsPerPlayer then
        return false, _L('max_requests')
    end

    local requestNumber = GenerateRequestNumber()
    local insertData = {
        request_number = requestNumber,
        citizenid = citizenid,
        player_name = player.name,
        source_id = source,
        category = data.category,
        type = data.type,
        description = data.description or '',
        priority = data.priority or Config.DefaultPriority,
        status = 'pending',
        coords = data.coords,
        street = data.street or 'Unknown',
        zone = data.zone or '',
        postal = data.postal or '',
        vehicle_model = data.vehicle_model,
        vehicle_name = data.vehicle_name,
        vehicle_plate = data.vehicle_plate
    }

    -- Retry up to 5 times if a duplicate request_number somehow occurs
    local id = nil
    for attempt = 1, 5 do
        insertData.request_number = requestNumber
        id = Database.InsertRequest(insertData)
        if id then break end
        -- Possible duplicate – generate a new number and try again
        requestNumber = GenerateRequestNumber()
        Wait(10)
    end
    if not id then return false, 'Database error' end

    -- Notify relevant employees
    Requests.NotifyProviders(data.category, data.type, {
        request_number = requestNumber,
        category = data.category,
        type = data.type,
        priority = data.priority,
        player_name = player.name,
        street = data.street,
        description = data.description
    })

    -- Discord webhook
    if Config.Webhooks.requestCreated and Config.Webhooks.requestCreated ~= '' then
        Requests.SendWebhook(Config.Webhooks.requestCreated, {
            title = 'New Service Request',
            description = ('**%s**\nCustomer: %s\nLocation: %s\nPriority: %s'):format(
                requestNumber, player.name, data.street or 'Unknown', data.priority or 'normal'
            ),
            color = 3447003
        })
    end

    return true, requestNumber
end

function Requests.NotifyProviders(category, typeId, payload)
    local players = Permissions.GetPlayers()
    for _, src in ipairs(players) do
        if Requests.IsAvailable(src) and Permissions.CanReceiveCategory(src, category, typeId) then
            TriggerClientEvent('stormys_sr:client:newRequest', src, payload)
            Permissions.Notify(src, _L('new_request', payload.type or category), 'inform')
        end
    end
end

function Requests.Accept(source, requestNumber)
    local player = Permissions.GetPlayer(source)
    if not player then return false, 'Player not found' end

    if not Permissions.IsServiceProvider(source) then
        return false, _L('no_permission')
    end

    local request = Database.GetRequest(requestNumber)
    if not request then return false, _L('request_not_found') end
    if request.status ~= 'pending' then
        return false, _L('request_already_taken')
    end

    if not Permissions.CanReceiveCategory(source, request.category, request.type) then
        return false, _L('no_permission')
    end

    local success = Database.UpdateStatus(requestNumber, 'accepted', {
        assigned_to = player.identifier,
        assigned_name = player.name,
        assigned_source = source
    })

    if not success then return false, 'Update failed' end

    -- Notify customer
    if request.source_id and GetPlayerPing(request.source_id) > 0 then
        Permissions.Notify(request.source_id, _L('request_accepted', requestNumber, player.name), 'success')
        TriggerClientEvent('stormys_sr:client:requestUpdated', request.source_id, requestNumber, 'accepted', player.name)
    end

    Permissions.Notify(source, _L('request_assigned', requestNumber), 'success')

    return true
end

function Requests.UpdateStatus(source, requestNumber, newStatus, extra)
    local player = Permissions.GetPlayer(source)
    if not player then return false, 'Player not found' end

    local request = Database.GetRequest(requestNumber)
    if not request then return false, _L('request_not_found') end

    -- Only assigned employee or admin can change status
    local isOwner = request.assigned_to == player.identifier
    local isAdmin = Permissions.IsAdmin(source)
    if not isOwner and not isAdmin then
        return false, _L('no_permission')
    end

    local validTransitions = {
        accepted   = { 'enroute', 'declined', 'cancelled' },
        enroute    = { 'arrived', 'cancelled' },
        arrived    = { 'inprogress', 'cancelled' },
        inprogress = { 'completed', 'cancelled' },
    }

    local allowed = validTransitions[request.status]
    if not allowed or not table.contains(allowed, newStatus) then
        if not isAdmin then
            return false, _L('invalid_status')
        end
    end

    -- Distance check for arrived
    if newStatus == 'arrived' then
        local ped = GetPlayerPed(source)
        local coords = GetEntityCoords(ped)
        local reqCoords = json.decode(request.coords or '{}')
        if reqCoords.x then
            local dist = #(coords - vector3(reqCoords.x, reqCoords.y, reqCoords.z))
            if dist > Config.ArrivalDistance then
                return false, _L('too_far')
            end
        end
    end

    local updateExtra = extra or {}
    local success = Database.UpdateStatus(requestNumber, newStatus, updateExtra)
    if not success then return false, 'Update failed' end

    -- Notify customer
    if request.source_id and GetPlayerPing(request.source_id) > 0 then
        if newStatus == 'arrived' then
            Permissions.Notify(request.source_id, _L('request_arrived'), 'inform')
        elseif newStatus == 'completed' then
            Permissions.Notify(request.source_id, _L('request_completed', requestNumber), 'success')
            -- Set cooldown
            playerCooldowns[request.citizenid] = os.time() + Config.CooldownAfterComplete
        elseif newStatus == 'cancelled' or newStatus == 'declined' then
            Permissions.Notify(request.source_id, _L('request_cancelled', requestNumber), 'error')
            playerCooldowns[request.citizenid] = os.time() + Config.CooldownAfterCancel
        end
        TriggerClientEvent('stormys_sr:client:requestUpdated', request.source_id, requestNumber, newStatus)
    end

    return true
end

function Requests.CancelByPlayer(source, requestNumber)
    local player = Permissions.GetPlayer(source)
    if not player then return false, 'Player not found' end

    local request = Database.GetRequest(requestNumber)
    if not request then return false, _L('request_not_found') end

    if request.citizenid ~= player.identifier then
        return false, _L('no_permission')
    end

    if request.status ~= 'pending' and request.status ~= 'accepted' then
        return false, 'Cannot cancel at this stage'
    end

    Database.CancelRequest(requestNumber)
    playerCooldowns[player.identifier] = os.time() + Config.CooldownAfterCancel

    -- Notify assigned employee if any
    if request.assigned_source and GetPlayerPing(request.assigned_source) > 0 then
        Permissions.Notify(request.assigned_source, 'Customer cancelled request ' .. requestNumber, 'error')
        TriggerClientEvent('stormys_sr:client:requestUpdated', request.assigned_source, requestNumber, 'cancelled')
    end

    return true
end

function Requests.GetPlayerRequests(source)
    local player = Permissions.GetPlayer(source)
    if not player then return {} end
    return Database.GetPlayerActiveRequests(player.identifier) or {}
end

function Requests.GetOpenForEmployee(source)
    if not Permissions.IsServiceProvider(source) then return {} end
    local all = Database.GetOpenRequests() or {}
    local filtered = {}
    for _, req in ipairs(all) do
        if Permissions.CanReceiveCategory(source, req.category, req.type) then
            filtered[#filtered+1] = req
        end
    end
    return filtered
end

function Requests.GetMyActive(source)
    local player = Permissions.GetPlayer(source)
    if not player then return {} end
    return Database.GetEmployeeActive(player.identifier) or {}
end

function Requests.SendWebhook(url, data)
    if not url or url == '' then return end
    PerformHttpRequest(url, function() end, 'POST', json.encode({
        embeds = {{
            title = data.title,
            description = data.description,
            color = data.color or 3447003,
            footer = { text = "Stormy’s Service Request" },
            timestamp = os.date('!%Y-%m-%dT%H:%M:%SZ')
        }}
    }), { ['Content-Type'] = 'application/json' })
end

-- Helper
function table.contains(tbl, val)
    for _, v in ipairs(tbl) do
        if v == val then return true end
    end
    return false
end

-- Cleanup on player drop
AddEventHandler('playerDropped', function()
    local src = source
    employeeAvailability[src] = nil
end)
-- ═══════════════════════════════════════════════════════════════
-- UNIVERSAL PAYMENT SYSTEM
-- ═══════════════════════════════════════════════════════════════

function Requests.CreateQuote(source, requestNumber, amount, description)
    if not Config.Payments.enabled then return false, 'Payments disabled' end

    local player = Permissions.GetPlayer(source)
    if not player then return false, 'Player not found' end

    local request = Database.GetRequest(requestNumber)
    if not request then return false, 'Request not found' end

    if request.assigned_to ~= player.identifier and not Permissions.IsAdmin(source) then
        return false, 'No permission'
    end

    amount = tonumber(amount)
    if not amount or amount < (Config.Payments.minAmount or 1) then
        return false, 'Invalid amount'
    end
    if Config.Payments.maxAmount > 0 and amount > Config.Payments.maxAmount then
        return false, 'Amount too high'
    end

    if request.payment_status == 'paid' then
        return false, 'Already paid'
    end

    Database.SetQuote(requestNumber, amount, description or '')

    if request.source_id and GetPlayerPing(request.source_id) > 0 then
        TriggerClientEvent('stormys_sr:client:quoteReceived', request.source_id, {
            request_number = requestNumber,
            amount = amount,
            description = description or '',
            provider = player.name
        })
        Permissions.Notify(request.source_id, 'You received a service quote for $' .. amount, 'inform')
    end

    return true
end

function Requests.ProcessPayment(source, requestNumber, method)
    if not Config.Payments.enabled then return false, 'Payments disabled' end

    local player = Permissions.GetPlayer(source)
    if not player then return false, 'Player not found' end

    local request = Database.GetRequest(requestNumber)
    if not request then return false, 'Request not found' end

    if request.citizenid ~= player.identifier then
        return false, 'No permission'
    end

    if request.payment_status == 'paid' then
        return false, 'Already paid'
    end

    if not request.quote_sent or not request.quote_amount then
        return false, 'No quote available'
    end

    local amount = tonumber(request.quote_amount)
    if not amount or amount <= 0 then return false, 'Invalid quote' end

    method = string.lower(method or '')
    if method ~= 'cash' and method ~= 'bank' then
        return false, 'Invalid payment method'
    end

    if method == 'cash' and not Config.Payments.allowCash then
        return false, 'Cash payments disabled'
    end
    if method == 'bank' and not Config.Payments.allowBank then
        return false, 'Bank payments disabled'
    end

    local success, err = Requests.RemoveMoney(source, method, amount)
    if not success then
        return false, err or 'Insufficient funds'
    end

    Database.MarkPaid(requestNumber, method, amount)

    Database.InsertPayment({
        request_number = requestNumber,
        citizenid = player.identifier,
        player_name = player.name,
        provider_id = request.assigned_to,
        provider_name = request.assigned_name,
        amount = amount,
        method = method,
        destination = Config.Payments.destination
    })

    Requests.GivePayment(request, amount, method)

    Permissions.Notify(source, 'Payment successful: $' .. amount .. ' (' .. method .. ')', 'success')
    TriggerClientEvent('stormys_sr:client:paymentSuccess', source, {
        request_number = requestNumber,
        amount = amount,
        method = method
    })

    if request.assigned_source and GetPlayerPing(request.assigned_source) > 0 then
        Permissions.Notify(request.assigned_source, 'Payment received: $' .. amount .. ' (' .. method .. ')', 'success')
        TriggerClientEvent('stormys_sr:client:paymentReceived', request.assigned_source, {
            request_number = requestNumber,
            amount = amount,
            method = method
        })
    end

    return true
end

function Requests.RemoveMoney(source, method, amount)
    local framework = Config.Framework

    if framework == 'qbcore' or framework == 'qbox' then
        local Player = nil
        if framework == 'qbcore' then
            local ok, QBCore = pcall(function() return exports['qb-core']:GetCoreObject() end)
            if ok and QBCore then Player = QBCore.Functions.GetPlayer(source) end
        else
            local ok, QBX = pcall(function() return exports.qbx_core end)
            if ok and QBX then Player = QBX:GetPlayer(source) end
        end
        if not Player then return false, 'Player not found' end

        if method == 'cash' then
            if (Player.PlayerData.money.cash or 0) < amount then return false, 'Insufficient cash' end
            Player.Functions.RemoveMoney('cash', amount, 'service-request-payment')
            return true
        else
            if (Player.PlayerData.money.bank or 0) < amount then return false, 'Insufficient bank funds' end
            Player.Functions.RemoveMoney('bank', amount, 'service-request-payment')
            return true
        end
    end

    if framework == 'esx' then
        local ESX = nil
        local ok, obj = pcall(function() return exports['es_extended']:getSharedObject() end)
        if ok then ESX = obj end
        if not ESX then
            TriggerEvent('esx:getSharedObject', function(o) ESX = o end)
            Wait(100)
        end
        if ESX then
            local xPlayer = ESX.GetPlayerFromId(source)
            if not xPlayer then return false, 'Player not found' end
            if method == 'cash' then
                if xPlayer.getMoney() < amount then return false, 'Insufficient cash' end
                xPlayer.removeMoney(amount)
                return true
            else
                if xPlayer.getAccount('bank').money < amount then return false, 'Insufficient bank funds' end
                xPlayer.removeAccountMoney('bank', amount)
                return true
            end
        end
    end

    if framework == 'standalone' then
        return true
    end

    return false, 'Framework money system not available'
end

function Requests.GivePayment(request, amount, method)
    local dest = Config.Payments.destination or 'provider'
    if dest ~= 'provider' then return end
    if not request.assigned_source or GetPlayerPing(request.assigned_source) <= 0 then return end

    local framework = Config.Framework
    if framework == 'qbcore' or framework == 'qbox' then
        local Player = nil
        if framework == 'qbcore' then
            local ok, QBCore = pcall(function() return exports['qb-core']:GetCoreObject() end)
            if ok and QBCore then Player = QBCore.Functions.GetPlayer(request.assigned_source) end
        else
            local ok, QBX = pcall(function() return exports.qbx_core end)
            if ok and QBX then Player = QBX:GetPlayer(request.assigned_source) end
        end
        if Player then
            Player.Functions.AddMoney(method == 'cash' and 'cash' or 'bank', amount, 'service-request-payment')
        end
    elseif framework == 'esx' then
        local ok, ESX = pcall(function() return exports['es_extended']:getSharedObject() end)
        if ok and ESX then
            local xPlayer = ESX.GetPlayerFromId(request.assigned_source)
            if xPlayer then
                if method == 'cash' then xPlayer.addMoney(amount) else xPlayer.addAccountMoney('bank', amount) end
            end
        end
    end
end
