-- Additional UI helpers (kept separate for cleanliness)

-- This file is intentionally light. Most UI logic lives in the NUI (html/js).
-- Client only handles focus, data bridging, and native interactions.