--[[
    SERVICE → JOB ROUTING

    This is the core of the universal provider system.
    Map categories and specific request types to the jobs that should receive them.

    Priority order:
    1. Specific type (e.g. 'therapist', 'taxi')
    2. Category (e.g. 'vehicle', 'medical')

    Add as many jobs as you want per entry.
]]

Config.JobRouting = {
    -- ═══════════════════════════════════════
    -- VEHICLE
    -- ═══════════════════════════════════════
    vehicle = {
        'mechanic',
        'bennys',
        'tuner',
        'tow'
    },
    vehicle_recovery = {
        'mechanic',
        'tow',
        'police'
    },
    roadside = {
        'mechanic',
        'tow'
    },

    -- ═══════════════════════════════════════
    -- MEDICAL
    -- ═══════════════════════════════════════
    medical = {
        'ambulance',
        'ems',
        'doctor'
    },
    ambulance = {
        'ambulance',
        'ems'
    },
    therapist = {
        'therapist',
        'psychologist',
        'doctor'
    },

    -- ═══════════════════════════════════════
    -- PUBLIC SAFETY
    -- ═══════════════════════════════════════
    public_safety = {
        'police',
        'sheriff'
    },
    non_emergency_police = {
        'police',
        'sheriff'
    },
    welfare_check = {
        'police',
        'sheriff',
        'ems'
    },

    -- ═══════════════════════════════════════
    -- PROPERTY / REAL ESTATE
    -- ═══════════════════════════════════════
    property = {
        'realestate',
        'realtor'
    },
    realtor_assist = {
        'realestate',
        'realtor'
    },
    property_viewing = {
        'realestate',
        'realtor'
    },
    property_inquiry = {
        'realestate',
        'realtor'
    },

    -- ═══════════════════════════════════════
    -- BUSINESS
    -- ═══════════════════════════════════════
    business = {
        'police',           -- fallback example
        'mechanic'
    },

    -- ═══════════════════════════════════════
    -- TRANSPORTATION
    -- ═══════════════════════════════════════
    transportation = {
        'taxi',
        'uber',
        'lyft'
    },
    taxi = {
        'taxi',
        'uber'
    },
    ride = {
        'taxi',
        'uber',
        'lyft'
    },

    -- ═══════════════════════════════════════
    -- CITY SERVICES
    -- ═══════════════════════════════════════
    city_services = {
        'garbage',
        'mechanic',
        'police'
    },
    road_hazard = {
        'police',
        'mechanic'
    },
    abandoned_vehicle = {
        'tow',
        'police'
    },

    -- ═══════════════════════════════════════
    -- PERSONAL (fallback)
    -- ═══════════════════════════════════════
    personal = {
        'police',
        'ambulance'
    },
}

-- Jobs that are considered service providers (can see employee tablet views)
Config.ServiceJobs = {
    -- Vehicle
    'mechanic', 'bennys', 'tuner', 'tow',
    -- Medical
    'ambulance', 'ems', 'doctor', 'therapist', 'psychologist',
    -- Public Safety
    'police', 'sheriff',
    -- Property
    'realestate', 'realtor',
    -- Transport
    'taxi', 'uber', 'lyft',
    -- City
    'garbage',
}